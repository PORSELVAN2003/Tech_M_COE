import 'package:flutter/material.dart';
import 'package:quiz1/quiz.dart';

void main() {
  runApp(const Quiz());
}