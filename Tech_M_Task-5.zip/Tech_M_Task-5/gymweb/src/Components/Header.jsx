import React from "react";

function Header() {
    return (
        <div id='main'>
            <div className="header-heading">
                <h2>STEP UP YOUR</h2>
                <h1><span>FITNESS</span> WITH US</h1>
                <p className="details">Build Your Body Healthy</p>
                <div className="header-btn-container">
                    <a href="javascript:void(0)" className="header-btn">JOIN US</a>
                </div>   
            </div>
        </div>
    );
}

export default Header;
