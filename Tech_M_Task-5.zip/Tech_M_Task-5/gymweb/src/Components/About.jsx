import React from "react";

function About(){
    return(
        <div id='about'>
            <div className="about-image">
                <img src={} alt=''/>
            </div>
        </div>
    )
}

export default About;